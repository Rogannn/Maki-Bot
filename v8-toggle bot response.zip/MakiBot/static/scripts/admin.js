$(document).ready(function(){
    $('#action_menu_btn').click(function(){
      $('.action_menu').toggle();
    });
  });

  // CONNECTION TO SERVER
    var socket = io.connect('http://127.0.0.1:5000');
    socket.emit('join', 'room1')
    $(document).ready(function() {
      msgerChat.scrollTop += 2000;
      socket.on('connection', function(socket) {
        socket.on('create', function(room) {
          socket.join(room);
          console.log("Admin has connected.");
        });
      });

      // RECEIVE CLIENT MESSAGE
      socket.on('message', function(msg) {
        showMessageBubble(USER_NAME, USER_IMG, msg);
      });
    });

    const msgerForm = get(".msger-inputarea");
    const msgerInput = get(".msger-input");
    const msgerChat = get(".card-body.msg_card_body");
    const chatLog = get(".chat-log")
    // BOT
    const BOT_NAME = "DHVSUAdmissionsBot";
    const BOT_IMG = "../static/styles/images/bot-icon.png";
    // USER
    var USER_NAME = "";
    var USER_IMG = "";
    // ADMIN
    var ADMIN_NAME = "DHVSU Admission Admin";
    var ADMIN_IMG = "../static/styles/images/user-icon.png";

    // SEND ADMIN MESSAGE
    $("#send-user-msg").on('click',  function() {
      event.preventDefault();
      if (!$('#user-input').val()) {
          alert("Input your message first!")
          return 
      }
      socket.send($('#user-input').val());
      $('#user-input').val('');
    });

    function showMessageBubble(name, img, text) {
    // side =  'start' or 'end' only
      const msgHTML = `
              <div class="d-flex justify-content-end mb-4">
                  <div class="msg_container_send">${text}</div>
                  <span class="msg_time_send">${formatDate(new Date())}</span>
              </div>`;
      msgerChat.insertAdjacentHTML("beforeend", msgHTML);
      msgerChat.scrollTop += 500;
    }

    // BOT RESPONSE
    function botResponse(rawText) {
      $.get("/get", { msg: rawText }).done(function (data) {
        console.log(rawText);
        console.log(data);
        const msgText = data;
        appendMessage(BOT_NAME, BOT_IMG, "left", msgText);
      });
    }

    // Utils
    function get(selector, root = document) {
      return root.querySelector(selector);
    }

    function formatDate(date) {
      const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
      const year = date.getFullYear();
      const month = months[date.getMonth()];
      const day = date.getDate();
      const hr = "0" + date.getHours();
      const min = "0" + date.getMinutes();
      return `${month} ${day}, ${hr.slice(-2)}:${min.slice(-2)}`;
    }
    // When the user scrolls the page, execute myFunction
    window.onscroll = function() {myFunction()};

    // Get the navbar
    var navbar = document.getElementById("navbar");

    // Get the offset position of the navbar
    var sticky = navbar.offsetTop;

    // Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
    function myFunction() {
      if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
      } else {
        navbar.classList.remove("sticky");
      }
    }